package simpleaddition;

public class SimpleAddition {

    public static void main(String[] args) {
        Addition addition = new Addition();
        addition.setVisible(true);
        
    }

}
